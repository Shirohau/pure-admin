# @oa/jsapi

OA 网页应用免登 SDK 的接口、包配置和调用封装。面向 Electron 应用容器和桌面浏览器，零运行时依赖，不依赖 Vue 或 Element Plus。

当前已提供 TypeScript 类型、结构化错误、就绪等待、超时、取消、能力查询，以及 Electron、浏览器两种真实适配器实现。两种适配器都只调用已上线的平台取码接口（`/sso/v1/desktop/...`），不产生模拟授权码；命名导出的 `ready`、`checkJsApi`、`requestAuthCode` 在桥不可用时返回 `BRIDGE_NOT_CONFIGURED`。包目前为 private，尚未发布到 npm，也未加入根项目依赖。

工作台启动入口已接入，2026-09-16 已在独立本机环境完成浏览器及真实 Electron 容器的点击、自动免登和退出测试。正式环境仍需分别配置客户端、可信来源及企业授权。完整接入步骤见[网页应用开发接入指南](../../doc/自研SDK/网页应用开发接入指南.md)。

## 调用接口

| 接口 | 返回内容 | 用途 |
| --- | --- | --- |
| `getEnv()` | `OaSdkEnvironment` | 同步读取适配器声明的环境和协议版本；未接入时环境为 `unknown` |
| `ready(options?)` | `Promise<OaReadyResult>` | 等待桥就绪并核对协议版本 |
| `checkJsApi({ apis }, options?)` | `Promise<{ apis: Record<string, boolean> }>` | 查询指定桥方法是否实现 |
| `requestAuthCode({ requestId }, options?)` | `Promise<{ code, requestId, expiresIn }>` | 对应用后台准备的交易取码 |

`getEnv` 不读取 User-Agent 或全局 `oaDesktop` 对象，不证明员工已登录。就绪和能力查询也不代表应用已获准访问；权限仍由可信容器和平台逐次核实。

调用选项为 `{ timeoutMs?: number, signal?: AbortSignal }`。默认总等待时间为 15000 毫秒，包含就绪等待；可设为大于 0、不超过 120000 毫秒的值。`expiresIn` 的单位是秒，以平台实际结果为准。SDK 不缓存授权码，不自动重试请求。

## 接入真实适配器

默认命名导出（`getEnv`/`ready`/`checkJsApi`/`requestAuthCode`）只自动装配 **Electron 应用容器桥**：页面若运行在 OA 桌面端由 `oa:open-app-container` 打开的隔离容器窗口内，其专用 preload 会注入 `window.oaAppBridge`，本包据此自动创建适配器，业务代码不用做任何配置：

```ts
import { requestAuthCode } from '@oa/jsapi'

const result = await requestAuthCode({ requestId }) // 非 Electron 容器环境下会抛出 BRIDGE_NOT_CONFIGURED
```

**浏览器场景**不会被默认单例自动装配，必须由业务应用显式提供 OA 平台的可信来源后自行创建实例：

```ts
import { createOaSdk, createBrowserAdapter } from '@oa/jsapi'

// platformOrigin 必须是业务应用自己写死的常量（与配置 OIDC 发现地址、redirect_uri 同等对待），
// 不能从页面 URL、referrer 或其它可被篡改的输入读取——否则一次性票据可能被带到攻击者的域名。
const sdk = createOaSdk(createBrowserAdapter({ platformOrigin: 'https://oa.example.com' }))

const result = await sdk.requestAuthCode({ requestId })
```

浏览器适配器要求页面地址带有工作台颁发的一次性票据（URL 查询参数 `oa_ticket`），读取后立即用 `history.replaceState` 从地址栏清除，不写入 `sessionStorage`/`localStorage`；票据只能成功兑换一次，用完或过期后同一个适配器实例不会自动重新取票，必须由工作台重新打开该应用生成新链接。请求直接以 `fetch` 跨域访问平台的 `/sso/v1/desktop/auth-codes/`（不使用 Cookie、iframe 或 postMessage），平台按票据关联的应用动态放行 CORS；当前页面来源未登记为该应用的可信来源时请求会被拒绝。

若要显式创建 Electron 适配器（例如需要跳过默认单例的自动装配逻辑），可调用 `createElectronAdapter()`；页面不在应用容器内时返回 `undefined`。

适配器统一声明 `environment: 'electron' | 'browser'` 和 `protocolVersion: 1`，实现 `ready(context)`、`checkJsApi(params, context)`、`requestAuthCode(params, context)`。每次异步调用前 SDK 都等待 `ready`，不会缓存某次就绪后永久复用其身份或上下文。适配器的环境和版本只用于兼容判断，不能成为安全授权依据。

适配器负责真实发送方、origin、窗口和导航代次校验，以及请求和响应关联。它必须处理传入的 `context.signal`，清理对应事件监听和资源，在账号、企业或页面变化后拒绝旧请求；用 `OaSdkError` 返回脱敏后的错误。不得把原始 HTTP 响应、授权头、token、code 或密钥放进错误消息。

## 页面调用样板

下面 `sdk` 是上文工厂创建的实例，`appApi` 由业务应用自己实现：

```ts
const controller = new AbortController()
const { requestId } = await appApi.prepareOaLogin({ signal: controller.signal })
const result = await sdk.requestAuthCode({ requestId }, {
  signal: controller.signal,
  timeoutMs: 15000,
})
await appApi.completeOaLogin(result, { signal: controller.signal })
// 只有应用后台确认本地登录已完成后，页面才进入业务页。
```

完整的页面状态处理样板见 `examples/login.ts`，通过类型明确区分 SDK、应用后台和界面三个接口，不包含伪造账号或本地登录实现。样板直接引用源码类型，便于仓库内阅读；应用正式安装包后使用 `@oa/jsapi` 命名导入。

应用后台仍需负责 PKCE、nonce、CSRF/来源校验、临时 Cookie 与交易绑定、身份令牌验证、账号映射、本地会话、刷新及退出失效。页面不持有 Client Secret、code_verifier 或 OA 主登录凭证，SDK 本身不会完成这些后台工作。

## 错误与取消

`OaSdkError` 提供 `{ code, message, requestId?, retryable }` 及 `toJSON()`。本包定义的错误码见 `src/types.ts`。未知适配器异常统一为 `UNKNOWN_ERROR`，不直接展示原始异常消息。

`retryable: true` 表示可重新准备整个登录流程，不能重放原 `requestId`、授权码或刷新令牌。超时和取消只表示页面已停止等待，平台可能已经消费交易；应结束旧交易，由应用后台重新准备新交易。应用退出后保留退出页面，不自动再次调用取码。

## 包与构建配置

源码入口为 `src/index.ts`。构建脚本 `scripts/build.mjs` 使用仓库已有版本的 TypeScript 和 esbuild，输出 ESM `dist/index.js`、CommonJS `dist/index.cjs`、声明 `dist/index.d.ts` 和 sourcemap。包中只有构建时依赖，没有运行依赖。

需要构建时可在仓库根目录调用 `node packages/oa-jsapi/scripts/build.mjs`。脚本路径不依赖终端当前目录；它先生成类型声明，再生成 JavaScript。产物不作为源码提交。npm 命名空间、公开发布、默认桥接入口与正式版本兼容策略应在认证核心接入时一并确定。
